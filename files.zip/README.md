# BillWise — iOS App

A SwiftUI bill & subscription management app with Firebase backend.

## Architecture
- **Pattern**: MVVM (Model-View-ViewModel)
- **UI**: SwiftUI (iOS 17+)
- **Backend**: Firebase Firestore + Firebase Auth
- **Notifications**: UserNotifications framework

---

## Project Structure

```
BillWise/
├── App/
│   ├── BillWiseApp.swift           # @main entry, Firebase config
│   └── AppState.swift              # Global app state / environment object
│
├── Models/
│   ├── User.swift
│   ├── Bill.swift
│   ├── Subscription.swift
│   ├── Category.swift
│   └── PaymentRecord.swift
│
├── ViewModels/
│   ├── AuthViewModel.swift
│   ├── DashboardViewModel.swift
│   ├── BillViewModel.swift
│   ├── SubscriptionViewModel.swift
│   └── AnalyticsViewModel.swift
│
├── Views/
│   ├── Auth/
│   │   ├── LoginView.swift
│   │   └── RegisterView.swift
│   ├── Dashboard/
│   │   └── DashboardView.swift
│   ├── Bills/
│   │   ├── BillListView.swift
│   │   ├── BillDetailView.swift
│   │   └── AddEditBillView.swift
│   ├── Subscriptions/
│   │   ├── SubscriptionListView.swift
│   │   ├── SubscriptionDetailView.swift
│   │   └── AddEditSubscriptionView.swift
│   ├── Analytics/
│   │   └── AnalyticsView.swift
│   └── Shared/
│       ├── MainTabView.swift
│       ├── CardView.swift
│       └── LoadingView.swift
│
├── Services/
│   ├── FirestoreService.swift
│   ├── AuthService.swift
│   └── NotificationService.swift
│
└── Utilities/
    ├── Extensions.swift
    └── Constants.swift
```

---

## Firestore Schema

```
users/{userId}
  ├── email: String
  ├── displayName: String
  ├── createdAt: Timestamp
  └── currency: String  // "USD", "GBP", etc.

users/{userId}/bills/{billId}
  ├── title: String
  ├── amount: Double
  ├── dueDate: Timestamp
  ├── category: String
  ├── isPaid: Bool
  ├── isRecurring: Bool
  ├── recurrenceInterval: String  // "monthly", "weekly", "yearly"
  ├── notes: String
  ├── reminderDays: Int           // days before due to remind
  └── createdAt: Timestamp

users/{userId}/subscriptions/{subId}
  ├── name: String
  ├── amount: Double
  ├── billingCycle: String        // "monthly", "yearly", "weekly"
  ├── nextBillingDate: Timestamp
  ├── category: String
  ├── provider: String
  ├── isActive: Bool
  ├── color: String               // hex color
  ├── icon: String                // SF Symbol name
  ├── reminderDays: Int
  └── createdAt: Timestamp

users/{userId}/payments/{paymentId}
  ├── billId: String?
  ├── subscriptionId: String?
  ├── amount: Double
  ├── paidAt: Timestamp
  └── note: String
```

---

## Setup Instructions

### 1. Firebase Setup
1. Create a new Firebase project at [console.firebase.google.com](https://console.firebase.google.com)
2. Add an iOS app with your bundle ID (e.g. `com.yourname.BillWise`)
3. Download `GoogleService-Info.plist` → drag into Xcode project root
4. Enable **Email/Password** authentication in Firebase Console → Authentication
5. Create a **Firestore Database** in production mode

### 2. Xcode Setup
1. Open Xcode → File → New → Project → App → Name: `BillWise`
2. Add Swift packages:
   - `https://github.com/firebase/firebase-ios-sdk` → select `FirebaseAuth`, `FirebaseFirestore`, `FirebaseFirestoreSwift`
3. Copy all source files from this project into the Xcode project
4. Add `GoogleService-Info.plist` to the target

### 3. Firestore Security Rules
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

### 4. Required Capabilities
- Add `UserNotifications` usage in Info.plist:
  ```xml
  <key>NSUserNotificationUsageDescription</key>
  <string>BillWise sends reminders before your bills are due.</string>
  ```

---

## Key Features
| Feature | Implementation |
|---|---|
| Auth | Firebase Email/Password + AppStorage session |
| Bills | Firestore CRUD with real-time listeners |
| Subscriptions | Firestore CRUD, auto-renewal tracking |
| Reminders | Local UNUserNotificationCenter |
| Analytics | Client-side aggregation of Firestore data |
| Dashboard | Live totals, upcoming due items |
