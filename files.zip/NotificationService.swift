// NotificationService.swift
// Schedules and manages local UNUserNotifications for bill/subscription reminders

import Foundation
import UserNotifications

final class NotificationService {
    static let shared = NotificationService()
    private let center = UNUserNotificationCenter.current()

    private init() {}

    // MARK: - Permission

    func requestAuthorization() async -> Bool {
        do {
            let granted = try await center.requestAuthorization(options: [.alert, .badge, .sound])
            return granted
        } catch {
            print("Notification auth error: \(error)")
            return false
        }
    }

    // MARK: - Schedule Bill Reminder

    func scheduleBillReminder(for bill: Bill) {
        guard !bill.isPaid, let id = bill.id else { return }

        let triggerDate = Calendar.current.date(
            byAdding: .day,
            value: -bill.reminderDays,
            to: bill.dueDate
        ) ?? bill.dueDate

        guard triggerDate > Date() else { return }

        let content = UNMutableNotificationContent()
        content.title = "Bill Due Soon 💸"
        content.body = "\(bill.title) of \(bill.amount.currencyFormatted) is due in \(bill.reminderDays) day(s)."
        content.sound = .default
        content.badge = 1
        content.userInfo = ["billId": id, "type": "bill"]

        let components = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: triggerDate)
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
        let request = UNNotificationRequest(identifier: "bill-\(id)", content: content, trigger: trigger)

        center.add(request) { error in
            if let error { print("Failed to schedule bill reminder: \(error)") }
        }
    }

    // MARK: - Schedule Subscription Reminder

    func scheduleSubscriptionReminder(for sub: Subscription) {
        guard sub.isActive, let id = sub.id else { return }

        let triggerDate = Calendar.current.date(
            byAdding: .day,
            value: -sub.reminderDays,
            to: sub.nextBillingDate
        ) ?? sub.nextBillingDate

        guard triggerDate > Date() else { return }

        let content = UNMutableNotificationContent()
        content.title = "Subscription Renewing Soon 🔔"
        content.body = "\(sub.name) will be charged \(sub.amount.currencyFormatted) in \(sub.reminderDays) day(s)."
        content.sound = .default
        content.badge = 1
        content.userInfo = ["subscriptionId": id, "type": "subscription"]

        let components = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: triggerDate)
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
        let request = UNNotificationRequest(identifier: "sub-\(id)", content: content, trigger: trigger)

        center.add(request) { error in
            if let error { print("Failed to schedule subscription reminder: \(error)") }
        }
    }

    // MARK: - Cancel Reminders

    func cancelBillReminder(id: String) {
        center.removePendingNotificationRequests(withIdentifiers: ["bill-\(id)"])
    }

    func cancelSubscriptionReminder(id: String) {
        center.removePendingNotificationRequests(withIdentifiers: ["sub-\(id)"])
    }

    func cancelAllReminders() {
        center.removeAllPendingNotificationRequests()
    }

    // MARK: - Reschedule All

    func rescheduleAll(bills: [Bill], subscriptions: [Subscription]) {
        cancelAllReminders()
        bills.forEach { scheduleBillReminder(for: $0) }
        subscriptions.filter { $0.isActive }.forEach { scheduleSubscriptionReminder(for: $0) }
    }
}

// Helper extension
private extension Double {
    var currencyFormatted: String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        return formatter.string(from: NSNumber(value: self)) ?? "$\(self)"
    }
}
