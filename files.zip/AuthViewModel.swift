// AuthViewModel.swift
// Manages authentication state and user session

import SwiftUI
import FirebaseAuth
import Combine

@MainActor
final class AuthViewModel: ObservableObject {
    @Published var user: FirebaseAuth.User?
    @Published var isLoading: Bool = true
    @Published var errorMessage: String?
    @Published var isSigningIn: Bool = false

    private var authHandle: AuthStateDidChangeListenerHandle?
    private let authService = AuthService.shared

    init() {
        authHandle = authService.addAuthStateListener { [weak self] user in
            self?.user = user
            self?.isLoading = false
        }
    }

    deinit {
        if let handle = authHandle {
            authService.removeAuthStateListener(handle)
        }
    }

    var uid: String { user?.uid ?? "" }

    func signIn(email: String, password: String) async {
        isSigningIn = true
        errorMessage = nil
        do {
            try await authService.signIn(email: email, password: password)
        } catch {
            errorMessage = error.localizedDescription
        }
        isSigningIn = false
    }

    func register(email: String, password: String, name: String) async {
        isSigningIn = true
        errorMessage = nil
        do {
            try await authService.register(email: email, password: password, name: name)
        } catch {
            errorMessage = error.localizedDescription
        }
        isSigningIn = false
    }

    func signOut() {
        do {
            try authService.signOut()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func resetPassword(email: String) async {
        do {
            try await authService.resetPassword(email: email)
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
