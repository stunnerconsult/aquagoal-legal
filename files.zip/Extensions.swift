// Extensions.swift

import SwiftUI

// MARK: - Double
extension Double {
    func currencyFormatted(symbol: String = "$") -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencySymbol = symbol
        formatter.maximumFractionDigits = 2
        return formatter.string(from: NSNumber(value: self)) ?? "\(symbol)\(self)"
    }
}

// MARK: - Date
extension Date {
    var isToday: Bool { Calendar.current.isDateInToday(self) }
    var isTomorrow: Bool { Calendar.current.isDateInTomorrow(self) }
    var isPast: Bool { self < Date() }

    var daysUntil: Int {
        Calendar.current.dateComponents([.day], from: Calendar.current.startOfDay(for: Date()),
                                         to: Calendar.current.startOfDay(for: self)).day ?? 0
    }

    var relativeLabel: String {
        if isToday { return "Today" }
        if isTomorrow { return "Tomorrow" }
        let days = daysUntil
        if days < 0 { return "\(abs(days))d overdue" }
        if days <= 7 { return "In \(days) days" }
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: self)
    }

    var shortMonthDay: String {
        let f = DateFormatter()
        f.dateFormat = "MMM d"
        return f.string(from: self)
    }

    var monthYear: String {
        let f = DateFormatter()
        f.dateFormat = "MMMM yyyy"
        return f.string(from: self)
    }
}

// MARK: - Color from Hex
extension Color {
    init(hex: String) {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")

        var rgb: UInt64 = 0
        Scanner(string: hexSanitized).scanHexInt64(&rgb)

        let r = Double((rgb >> 16) & 0xFF) / 255
        let g = Double((rgb >> 8) & 0xFF) / 255
        let b = Double(rgb & 0xFF) / 255
        self.init(red: r, green: g, blue: b)
    }

    var hex: String {
        let uiColor = UIColor(self)
        var r: CGFloat = 0; var g: CGFloat = 0; var b: CGFloat = 0; var a: CGFloat = 0
        uiColor.getRed(&r, green: &g, blue: &b, alpha: &a)
        return String(format: "#%02X%02X%02X", Int(r * 255), Int(g * 255), Int(b * 255))
    }
}

// MARK: - View Modifiers
extension View {
    func cardStyle(cornerRadius: CGFloat = 16) -> some View {
        self
            .background(Color(.secondarySystemBackground))
            .cornerRadius(cornerRadius)
    }

    func shadowCard() -> some View {
        self
            .background(Color(.systemBackground))
            .cornerRadius(16)
            .shadow(color: .black.opacity(0.06), radius: 8, x: 0, y: 2)
    }
}

// MARK: - Constants
enum Constants {
    static let appName = "BillWise"
    static let accentColor = Color(hex: "#4F6EF7")
    static let successColor = Color(hex: "#34C759")
    static let warningColor = Color(hex: "#FF9500")
    static let dangerColor  = Color(hex: "#FF3B30")

    enum Padding {
        static let screen: CGFloat = 20
        static let card: CGFloat = 16
        static let small: CGFloat = 8
    }

    enum Animation {
        static let standard = SwiftUI.Animation.easeInOut(duration: 0.25)
        static let spring   = SwiftUI.Animation.spring(response: 0.4, dampingFraction: 0.7)
    }
}
