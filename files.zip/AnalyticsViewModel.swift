// DashboardViewModel.swift

import SwiftUI
import Combine

@MainActor
final class DashboardViewModel: ObservableObject {
    @Published var greeting: String = ""
    @Published var userName: String = ""

    init() {
        refreshGreeting()
    }

    func refreshGreeting() {
        let hour = Calendar.current.component(.hour, from: Date())
        switch hour {
        case 0..<12:  greeting = "Good morning"
        case 12..<17: greeting = "Good afternoon"
        default:      greeting = "Good evening"
        }
    }

    func setup(name: String) {
        userName = name.components(separatedBy: " ").first ?? name
        refreshGreeting()
    }
}

// MARK: -

// AnalyticsViewModel.swift

import SwiftUI
import Combine

struct MonthlySpend: Identifiable {
    var id: String { month }
    let month: String       // "Jan", "Feb", …
    let amount: Double
}

struct CategorySpend: Identifiable {
    var id: String { category.rawValue }
    let category: BillCategory
    let amount: Double
}

@MainActor
final class AnalyticsViewModel: ObservableObject {
    @Published var monthlySpendData: [MonthlySpend] = []
    @Published var categoryBreakdown: [CategorySpend] = []
    @Published var totalThisMonth: Double = 0
    @Published var totalLastMonth: Double = 0
    @Published var isLoading: Bool = false
    @Published var selectedPeriod: Period = .last6Months

    enum Period: String, CaseIterable {
        case last3Months = "3M"
        case last6Months = "6M"
        case lastYear    = "1Y"
    }

    private let firestore = FirestoreService.shared

    func loadAnalytics(uid: String, bills: [Bill], subscriptions: [Subscription]) {
        isLoading = true

        let cal = Calendar.current
        let now = Date()

        // Build monthly spend from bills
        let monthCount: Int
        switch selectedPeriod {
        case .last3Months: monthCount = 3
        case .last6Months: monthCount = 6
        case .lastYear:    monthCount = 12
        }

        var monthly: [MonthlySpend] = []
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM"

        for i in (0..<monthCount).reversed() {
            guard let monthStart = cal.date(byAdding: .month, value: -i, to: now),
                  let start = cal.date(from: cal.dateComponents([.year, .month], from: monthStart)),
                  let end = cal.date(byAdding: .month, value: 1, to: start)
            else { continue }

            let billsTotal = bills
                .filter { $0.dueDate >= start && $0.dueDate < end }
                .reduce(0) { $0 + $1.amount }

            let subsTotal = subscriptions
                .filter { $0.isActive }
                .reduce(0) { $0 + $1.monthlyEquivalent }

            let label = formatter.string(from: start)
            monthly.append(MonthlySpend(month: label, amount: billsTotal + (i == 0 ? subsTotal : subsTotal)))
        }

        monthlySpendData = monthly

        // This month vs last month totals
        let thisMonthStart = cal.date(from: cal.dateComponents([.year, .month], from: now))!
        let lastMonthStart = cal.date(byAdding: .month, value: -1, to: thisMonthStart)!

        totalThisMonth = bills
            .filter { $0.dueDate >= thisMonthStart && $0.dueDate < now }
            .reduce(0) { $0 + $1.amount }
        + subscriptions.filter { $0.isActive }.reduce(0) { $0 + $1.monthlyEquivalent }

        totalLastMonth = bills
            .filter { $0.dueDate >= lastMonthStart && $0.dueDate < thisMonthStart }
            .reduce(0) { $0 + $1.amount }
        + subscriptions.filter { $0.isActive }.reduce(0) { $0 + $1.monthlyEquivalent }

        // Category breakdown
        var catTotals: [BillCategory: Double] = [:]
        bills.filter { $0.dueDate >= thisMonthStart }.forEach {
            catTotals[$0.category, default: 0] += $0.amount
        }
        subscriptions.filter { $0.isActive }.forEach {
            catTotals[$0.category, default: 0] += $0.monthlyEquivalent
        }

        categoryBreakdown = catTotals
            .map { CategorySpend(category: $0.key, amount: $0.value) }
            .sorted { $0.amount > $1.amount }

        isLoading = false
    }

    var changePercent: Double {
        guard totalLastMonth > 0 else { return 0 }
        return ((totalThisMonth - totalLastMonth) / totalLastMonth) * 100
    }

    var isSpendingUp: Bool { totalThisMonth > totalLastMonth }
}
