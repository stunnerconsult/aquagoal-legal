// Models.swift
// All domain models conforming to Codable + Identifiable for Firestore

import Foundation
import FirebaseFirestore
import FirebaseFirestoreSwift

// MARK: - BillWiseUser
struct BillWiseUser: Codable, Identifiable {
    @DocumentID var id: String?
    var email: String
    var displayName: String
    var currency: String
    var createdAt: Date

    enum CodingKeys: String, CodingKey {
        case id, email, displayName, currency, createdAt
    }
}

// MARK: - Bill
struct Bill: Codable, Identifiable {
    @DocumentID var id: String?
    var title: String
    var amount: Double
    var dueDate: Date
    var category: BillCategory
    var isPaid: Bool
    var isRecurring: Bool
    var recurrenceInterval: RecurrenceInterval?
    var notes: String
    var reminderDays: Int          // e.g. 3 = remind 3 days before due
    var createdAt: Date

    // Computed
    var isOverdue: Bool {
        !isPaid && dueDate < Date()
    }

    var isDueSoon: Bool {
        let days = Calendar.current.dateComponents([.day], from: Date(), to: dueDate).day ?? 0
        return !isPaid && days >= 0 && days <= reminderDays
    }

    static var preview: Bill {
        Bill(
            id: "preview",
            title: "Electric Bill",
            amount: 85.50,
            dueDate: Calendar.current.date(byAdding: .day, value: 5, to: Date())!,
            category: .utilities,
            isPaid: false,
            isRecurring: true,
            recurrenceInterval: .monthly,
            notes: "Check meter reading",
            reminderDays: 3,
            createdAt: Date()
        )
    }
}

// MARK: - Subscription
struct Subscription: Codable, Identifiable {
    @DocumentID var id: String?
    var name: String
    var amount: Double
    var billingCycle: BillingCycle
    var nextBillingDate: Date
    var category: BillCategory
    var provider: String
    var isActive: Bool
    var colorHex: String           // e.g. "#FF6B6B"
    var icon: String               // SF Symbol name e.g. "tv.fill"
    var reminderDays: Int
    var createdAt: Date

    var monthlyEquivalent: Double {
        switch billingCycle {
        case .weekly:   return amount * 52 / 12
        case .monthly:  return amount
        case .yearly:   return amount / 12
        }
    }

    static var preview: Subscription {
        Subscription(
            id: "preview",
            name: "Netflix",
            amount: 15.99,
            billingCycle: .monthly,
            nextBillingDate: Calendar.current.date(byAdding: .day, value: 12, to: Date())!,
            category: .entertainment,
            provider: "Netflix Inc.",
            isActive: true,
            colorHex: "#E50914",
            icon: "play.rectangle.fill",
            reminderDays: 2,
            createdAt: Date()
        )
    }
}

// MARK: - PaymentRecord
struct PaymentRecord: Codable, Identifiable {
    @DocumentID var id: String?
    var billId: String?
    var subscriptionId: String?
    var amount: Double
    var paidAt: Date
    var note: String

    var type: PaymentType {
        billId != nil ? .bill : .subscription
    }

    enum PaymentType {
        case bill, subscription
    }
}

// MARK: - Enums

enum BillCategory: String, Codable, CaseIterable {
    case utilities      = "Utilities"
    case rent           = "Rent / Mortgage"
    case insurance      = "Insurance"
    case entertainment  = "Entertainment"
    case food           = "Food & Dining"
    case transport      = "Transport"
    case health         = "Health"
    case education      = "Education"
    case shopping       = "Shopping"
    case other          = "Other"

    var icon: String {
        switch self {
        case .utilities:     return "bolt.fill"
        case .rent:          return "house.fill"
        case .insurance:     return "shield.fill"
        case .entertainment: return "tv.fill"
        case .food:          return "fork.knife"
        case .transport:     return "car.fill"
        case .health:        return "heart.fill"
        case .education:     return "book.fill"
        case .shopping:      return "bag.fill"
        case .other:         return "ellipsis.circle.fill"
        }
    }

    var color: String {
        switch self {
        case .utilities:     return "#FFB347"
        case .rent:          return "#6C91BF"
        case .insurance:     return "#88C0D0"
        case .entertainment: return "#E50914"
        case .food:          return "#A3BE8C"
        case .transport:     return "#5E81AC"
        case .health:        return "#BF616A"
        case .education:     return "#D08770"
        case .shopping:      return "#B48EAD"
        case .other:         return "#8B9BB4"
        }
    }
}

enum RecurrenceInterval: String, Codable, CaseIterable {
    case weekly  = "weekly"
    case monthly = "monthly"
    case yearly  = "yearly"

    var displayName: String {
        switch self {
        case .weekly:  return "Weekly"
        case .monthly: return "Monthly"
        case .yearly:  return "Yearly"
        }
    }
}

enum BillingCycle: String, Codable, CaseIterable {
    case weekly  = "weekly"
    case monthly = "monthly"
    case yearly  = "yearly"

    var displayName: String {
        switch self {
        case .weekly:  return "Weekly"
        case .monthly: return "Monthly"
        case .yearly:  return "Yearly"
        }
    }

    var shortLabel: String {
        switch self {
        case .weekly:  return "/wk"
        case .monthly: return "/mo"
        case .yearly:  return "/yr"
        }
    }
}
