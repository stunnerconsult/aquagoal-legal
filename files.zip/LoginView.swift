// LoginView.swift

import SwiftUI

struct LoginView: View {
    @EnvironmentObject var authVM: AuthViewModel
    @State private var email = ""
    @State private var password = ""
    @State private var showRegister = false
    @State private var showForgot = false
    @FocusState private var focusedField: Field?

    enum Field { case email, password }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 0) {
                    // Header
                    VStack(spacing: 8) {
                        Image(systemName: "dollarsign.circle.fill")
                            .font(.system(size: 64))
                            .foregroundStyle(Constants.accentColor)
                            .padding(.top, 60)
                            .padding(.bottom, 8)

                        Text("BillWise")
                            .font(.system(size: 36, weight: .bold, design: .rounded))
                        Text("Your bills, beautifully organized")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.bottom, 48)

                    // Form
                    VStack(spacing: 16) {
                        AuthTextField(
                            placeholder: "Email address",
                            icon: "envelope.fill",
                            text: $email,
                            keyboardType: .emailAddress,
                            textContentType: .emailAddress
                        )
                        .focused($focusedField, equals: .email)
                        .submitLabel(.next)
                        .onSubmit { focusedField = .password }

                        AuthTextField(
                            placeholder: "Password",
                            icon: "lock.fill",
                            text: $password,
                            isSecure: true,
                            textContentType: .password
                        )
                        .focused($focusedField, equals: .password)
                        .submitLabel(.go)
                        .onSubmit { Task { await authVM.signIn(email: email, password: password) } }

                        if let error = authVM.errorMessage {
                            HStack {
                                Image(systemName: "exclamationmark.triangle.fill")
                                    .foregroundStyle(Constants.dangerColor)
                                Text(error)
                                    .font(.caption)
                                    .foregroundStyle(Constants.dangerColor)
                                Spacer()
                            }
                        }

                        Button {
                            Task { await authVM.signIn(email: email, password: password) }
                        } label: {
                            Group {
                                if authVM.isSigningIn {
                                    ProgressView().tint(.white)
                                } else {
                                    Text("Sign In")
                                        .font(.headline)
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 52)
                            .background(Constants.accentColor, in: RoundedRectangle(cornerRadius: 14))
                            .foregroundStyle(.white)
                        }
                        .disabled(authVM.isSigningIn || email.isEmpty || password.isEmpty)

                        Button("Forgot Password?") { showForgot = true }
                            .font(.subheadline)
                            .foregroundStyle(Constants.accentColor)
                    }
                    .padding(.horizontal, Constants.Padding.screen)

                    Spacer(minLength: 48)

                    // Register CTA
                    HStack {
                        Text("Don't have an account?")
                            .foregroundStyle(.secondary)
                        Button("Create one") { showRegister = true }
                            .fontWeight(.semibold)
                            .foregroundStyle(Constants.accentColor)
                    }
                    .font(.subheadline)
                    .padding(.bottom, 32)
                }
            }
            .scrollDismissesKeyboard(.interactively)
            .navigationDestination(isPresented: $showRegister) { RegisterView() }
            .sheet(isPresented: $showForgot) { ForgotPasswordView() }
        }
    }
}

// MARK: - RegisterView
struct RegisterView: View {
    @EnvironmentObject var authVM: AuthViewModel
    @Environment(\.dismiss) var dismiss

    @State private var name = ""
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @FocusState private var focusedField: Field?

    enum Field { case name, email, password, confirm }

    var passwordMismatch: Bool { !confirmPassword.isEmpty && confirmPassword != password }

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                VStack(spacing: 8) {
                    Image(systemName: "person.crop.circle.fill.badge.plus")
                        .font(.system(size: 56))
                        .foregroundStyle(Constants.accentColor)
                        .padding(.top, 40)
                        .padding(.bottom, 8)
                    Text("Create Account")
                        .font(.title.bold())
                    Text("Start tracking your bills today")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .padding(.bottom, 40)

                VStack(spacing: 16) {
                    AuthTextField(placeholder: "Full name", icon: "person.fill", text: $name, textContentType: .name)
                        .focused($focusedField, equals: .name)
                    AuthTextField(placeholder: "Email", icon: "envelope.fill", text: $email, keyboardType: .emailAddress, textContentType: .emailAddress)
                        .focused($focusedField, equals: .email)
                    AuthTextField(placeholder: "Password", icon: "lock.fill", text: $password, isSecure: true, textContentType: .newPassword)
                        .focused($focusedField, equals: .password)
                    AuthTextField(placeholder: "Confirm Password", icon: "lock.fill", text: $confirmPassword, isSecure: true, textContentType: .newPassword)
                        .focused($focusedField, equals: .confirm)

                    if passwordMismatch {
                        HStack {
                            Image(systemName: "exclamationmark.triangle.fill")
                            Text("Passwords don't match")
                            Spacer()
                        }
                        .font(.caption)
                        .foregroundStyle(Constants.dangerColor)
                    }

                    if let error = authVM.errorMessage {
                        HStack {
                            Image(systemName: "exclamationmark.triangle.fill")
                            Text(error)
                            Spacer()
                        }
                        .font(.caption)
                        .foregroundStyle(Constants.dangerColor)
                    }

                    Button {
                        Task { await authVM.register(email: email, password: password, name: name) }
                    } label: {
                        Group {
                            if authVM.isSigningIn {
                                ProgressView().tint(.white)
                            } else {
                                Text("Create Account").font(.headline)
                            }
                        }
                        .frame(maxWidth: .infinity).frame(height: 52)
                        .background(Constants.accentColor, in: RoundedRectangle(cornerRadius: 14))
                        .foregroundStyle(.white)
                    }
                    .disabled(authVM.isSigningIn || name.isEmpty || email.isEmpty || password.count < 6 || passwordMismatch)
                }
                .padding(.horizontal, Constants.Padding.screen)
            }
        }
        .navigationTitle("Register")
        .navigationBarTitleDisplayMode(.inline)
        .scrollDismissesKeyboard(.interactively)
    }
}

// MARK: - ForgotPasswordView
struct ForgotPasswordView: View {
    @EnvironmentObject var authVM: AuthViewModel
    @Environment(\.dismiss) var dismiss
    @State private var email = ""
    @State private var sent = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                Text("Enter your email and we'll send you a password reset link.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)

                AuthTextField(placeholder: "Email address", icon: "envelope.fill", text: $email, keyboardType: .emailAddress, textContentType: .emailAddress)

                if sent {
                    HStack {
                        Image(systemName: "checkmark.circle.fill").foregroundStyle(Constants.successColor)
                        Text("Reset email sent!").foregroundStyle(Constants.successColor)
                    }
                    .font(.subheadline.weight(.medium))
                }

                Button {
                    Task {
                        await authVM.resetPassword(email: email)
                        sent = true
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { dismiss() }
                    }
                } label: {
                    Text("Send Reset Link")
                        .font(.headline)
                        .frame(maxWidth: .infinity).frame(height: 52)
                        .background(Constants.accentColor, in: RoundedRectangle(cornerRadius: 14))
                        .foregroundStyle(.white)
                }
                .disabled(email.isEmpty)

                Spacer()
            }
            .padding(Constants.Padding.screen)
            .navigationTitle("Reset Password")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } } }
        }
    }
}

// MARK: - AuthTextField
struct AuthTextField: View {
    let placeholder: String
    let icon: String
    @Binding var text: String
    var keyboardType: UIKeyboardType = .default
    var textContentType: UITextContentType? = nil
    var isSecure: Bool = false

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(Constants.accentColor)
                .frame(width: 20)

            if isSecure {
                SecureField(placeholder, text: $text)
                    .textContentType(textContentType)
                    .autocorrectionDisabled()
            } else {
                TextField(placeholder, text: $text)
                    .keyboardType(keyboardType)
                    .textContentType(textContentType)
                    .autocorrectionDisabled()
                    .autocapitalization(.none)
            }
        }
        .padding(14)
        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
    }
}
