// BillListView.swift

import SwiftUI

struct BillListView: View {
    @EnvironmentObject var billVM: BillViewModel
    @EnvironmentObject var authVM: AuthViewModel
    @State private var showAdd = false
    @State private var filter: BillFilter = .all
    @State private var searchText = ""

    enum BillFilter: String, CaseIterable {
        case all = "All"
        case upcoming = "Upcoming"
        case overdue = "Overdue"
        case paid = "Paid"
    }

    var filteredBills: [Bill] {
        let base: [Bill]
        switch filter {
        case .all:      base = billVM.bills
        case .upcoming: base = billVM.upcomingBills
        case .overdue:  base = billVM.overdueBills
        case .paid:     base = billVM.paidBills
        }
        guard !searchText.isEmpty else { return base }
        return base.filter { $0.title.localizedCaseInsensitiveContains(searchText) }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Filter chips
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(BillFilter.allCases, id: \.self) { f in
                            FilterChip(label: f.rawValue, isSelected: filter == f) {
                                withAnimation(Constants.Animation.standard) { filter = f }
                            }
                        }
                    }
                    .padding(.horizontal, Constants.Padding.screen)
                    .padding(.vertical, 12)
                }

                if billVM.isLoading {
                    ProgressView().frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if filteredBills.isEmpty {
                    EmptyStateView(
                        icon: "doc.text.fill",
                        title: "No Bills",
                        subtitle: "Add a bill using the + button"
                    )
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List {
                        ForEach(filteredBills) { bill in
                            NavigationLink(destination: BillDetailView(bill: bill)) {
                                BillRowView(bill: bill)
                            }
                            .listRowSeparator(.hidden)
                            .listRowInsets(EdgeInsets(top: 4, leading: 16, bottom: 4, trailing: 16))
                        }
                        .onDelete { indexSet in
                            indexSet.forEach { i in
                                Task { await billVM.deleteBill(filteredBills[i], uid: authVM.uid) }
                            }
                        }
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("Bills")
            .searchable(text: $searchText, prompt: "Search bills")
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button { showAdd = true } label: {
                        Image(systemName: "plus.circle.fill")
                            .font(.title2)
                            .foregroundStyle(Constants.accentColor)
                    }
                }
            }
            .sheet(isPresented: $showAdd) {
                AddEditBillView(mode: .add)
            }
        }
    }
}

// MARK: - BillRowView
struct BillRowView: View {
    let bill: Bill
    @EnvironmentObject var billVM: BillViewModel
    @EnvironmentObject var authVM: AuthViewModel

    var statusColor: Color {
        if bill.isOverdue { return Constants.dangerColor }
        if bill.isDueSoon { return Constants.warningColor }
        return .secondary
    }

    var body: some View {
        HStack(spacing: 12) {
            // Category Icon
            ZStack {
                Circle()
                    .fill(Color(hex: bill.category.color).opacity(0.15))
                    .frame(width: 44, height: 44)
                Image(systemName: bill.category.icon)
                    .font(.system(size: 18, weight: .medium))
                    .foregroundStyle(Color(hex: bill.category.color))
            }

            // Info
            VStack(alignment: .leading, spacing: 4) {
                Text(bill.title)
                    .font(.subheadline.weight(.semibold))
                    .lineLimit(1)
                HStack(spacing: 6) {
                    Image(systemName: "calendar")
                        .font(.caption2)
                    Text(bill.dueDate.relativeLabel)
                        .font(.caption)
                }
                .foregroundStyle(statusColor)
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 6) {
                Text(bill.amount.currencyFormatted())
                    .font(.subheadline.weight(.bold))

                // Paid toggle
                Button {
                    Task { await billVM.togglePaid(bill, uid: authVM.uid) }
                } label: {
                    Image(systemName: bill.isPaid ? "checkmark.circle.fill" : "circle")
                        .font(.title3)
                        .foregroundStyle(bill.isPaid ? Constants.successColor : .secondary)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(Constants.Padding.card)
        .shadowCard()
    }
}

// MARK: - BillDetailView
struct BillDetailView: View {
    @EnvironmentObject var billVM: BillViewModel
    @EnvironmentObject var authVM: AuthViewModel
    @Environment(\.dismiss) var dismiss

    let bill: Bill
    @State private var showEdit = false
    @State private var showDeleteAlert = false

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Hero
                VStack(spacing: 12) {
                    ZStack {
                        Circle()
                            .fill(Color(hex: bill.category.color).opacity(0.15))
                            .frame(width: 80, height: 80)
                        Image(systemName: bill.category.icon)
                            .font(.system(size: 36))
                            .foregroundStyle(Color(hex: bill.category.color))
                    }

                    Text(bill.title)
                        .font(.title2.bold())
                    Text(bill.amount.currencyFormatted())
                        .font(.system(size: 36, weight: .bold, design: .rounded))
                        .foregroundStyle(Constants.accentColor)

                    StatusPill(bill: bill)
                }
                .padding(.top, 20)

                // Details card
                VStack(spacing: 0) {
                    DetailRow(label: "Category", value: bill.category.rawValue)
                    Divider().padding(.leading, 16)
                    DetailRow(label: "Due Date", value: bill.dueDate.relativeLabel)
                    Divider().padding(.leading, 16)
                    DetailRow(label: "Recurring", value: bill.isRecurring ? (bill.recurrenceInterval?.displayName ?? "Yes") : "No")
                    Divider().padding(.leading, 16)
                    DetailRow(label: "Reminder", value: "\(bill.reminderDays) day(s) before")
                    if !bill.notes.isEmpty {
                        Divider().padding(.leading, 16)
                        DetailRow(label: "Notes", value: bill.notes)
                    }
                }
                .shadowCard()
                .padding(.horizontal, Constants.Padding.screen)

                // Actions
                VStack(spacing: 12) {
                    Button {
                        Task { await billVM.togglePaid(bill, uid: authVM.uid) }
                        dismiss()
                    } label: {
                        Label(bill.isPaid ? "Mark as Unpaid" : "Mark as Paid",
                              systemImage: bill.isPaid ? "xmark.circle" : "checkmark.circle.fill")
                            .font(.headline)
                            .frame(maxWidth: .infinity).frame(height: 52)
                            .background(bill.isPaid ? Color.secondary.opacity(0.2) : Constants.successColor,
                                        in: RoundedRectangle(cornerRadius: 14))
                            .foregroundStyle(bill.isPaid ? .secondary : .white)
                    }

                    Button(role: .destructive) { showDeleteAlert = true } label: {
                        Label("Delete Bill", systemImage: "trash")
                            .font(.headline)
                            .frame(maxWidth: .infinity).frame(height: 52)
                            .background(Constants.dangerColor.opacity(0.1), in: RoundedRectangle(cornerRadius: 14))
                            .foregroundStyle(Constants.dangerColor)
                    }
                }
                .padding(.horizontal, Constants.Padding.screen)
            }
        }
        .navigationTitle(bill.category.rawValue)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button("Edit") { showEdit = true }
                    .foregroundStyle(Constants.accentColor)
            }
        }
        .sheet(isPresented: $showEdit) {
            AddEditBillView(mode: .edit(bill))
        }
        .alert("Delete Bill?", isPresented: $showDeleteAlert) {
            Button("Delete", role: .destructive) {
                Task {
                    await billVM.deleteBill(bill, uid: authVM.uid)
                    dismiss()
                }
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("This action cannot be undone.")
        }
    }
}

// MARK: - AddEditBillView
enum FormMode<T> {
    case add
    case edit(T)
}

struct AddEditBillView: View {
    @EnvironmentObject var billVM: BillViewModel
    @EnvironmentObject var authVM: AuthViewModel
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) var dismiss

    let mode: FormMode<Bill>

    @State private var title = ""
    @State private var amount = ""
    @State private var dueDate = Date()
    @State private var category: BillCategory = .utilities
    @State private var isRecurring = false
    @State private var recurrence: RecurrenceInterval = .monthly
    @State private var notes = ""
    @State private var reminderDays = 3
    @State private var isSaving = false

    var isEditing: Bool {
        if case .edit = mode { return true }
        return false
    }

    var originalBill: Bill? {
        if case .edit(let b) = mode { return b }
        return nil
    }

    var isValid: Bool { !title.isEmpty && Double(amount) != nil }

    var body: some View {
        NavigationStack {
            Form {
                Section("Details") {
                    TextField("Bill title", text: $title)
                    HStack {
                        Text("$")
                        TextField("Amount", text: $amount)
                            .keyboardType(.decimalPad)
                    }
                    DatePicker("Due Date", selection: $dueDate, displayedComponents: .date)
                    Picker("Category", selection: $category) {
                        ForEach(BillCategory.allCases, id: \.self) { cat in
                            Label(cat.rawValue, systemImage: cat.icon).tag(cat)
                        }
                    }
                }

                Section("Recurrence") {
                    Toggle("Recurring Bill", isOn: $isRecurring)
                    if isRecurring {
                        Picker("Interval", selection: $recurrence) {
                            ForEach(RecurrenceInterval.allCases, id: \.self) {
                                Text($0.displayName).tag($0)
                            }
                        }
                    }
                }

                Section("Reminder") {
                    Stepper("Remind \(reminderDays) day(s) before", value: $reminderDays, in: 1...14)
                }

                Section("Notes") {
                    TextField("Optional notes", text: $notes, axis: .vertical)
                        .lineLimit(3...6)
                }
            }
            .navigationTitle(isEditing ? "Edit Bill" : "New Bill")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button(isSaving ? "Saving…" : "Save") {
                        Task { await save() }
                    }
                    .disabled(!isValid || isSaving)
                    .fontWeight(.semibold)
                }
            }
            .onAppear { populateIfEditing() }
        }
    }

    private func populateIfEditing() {
        guard let bill = originalBill else { return }
        title = bill.title
        amount = String(bill.amount)
        dueDate = bill.dueDate
        category = bill.category
        isRecurring = bill.isRecurring
        recurrence = bill.recurrenceInterval ?? .monthly
        notes = bill.notes
        reminderDays = bill.reminderDays
    }

    private func save() async {
        isSaving = true
        let bill = Bill(
            id: originalBill?.id,
            title: title,
            amount: Double(amount) ?? 0,
            dueDate: dueDate,
            category: category,
            isPaid: originalBill?.isPaid ?? false,
            isRecurring: isRecurring,
            recurrenceInterval: isRecurring ? recurrence : nil,
            notes: notes,
            reminderDays: reminderDays,
            createdAt: originalBill?.createdAt ?? Date()
        )
        if isEditing {
            await billVM.updateBill(bill, uid: authVM.uid)
        } else {
            await billVM.addBill(bill, uid: authVM.uid)
        }
        appState.showSuccess(isEditing ? "Bill updated!" : "Bill added!")
        isSaving = false
        dismiss()
    }
}

// MARK: - Reusable components

struct FilterChip: View {
    let label: String
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(label)
                .font(.subheadline.weight(isSelected ? .semibold : .regular))
                .padding(.horizontal, 14)
                .padding(.vertical, 7)
                .background(isSelected ? Constants.accentColor : Color(.secondarySystemBackground),
                            in: Capsule())
                .foregroundStyle(isSelected ? .white : .primary)
        }
    }
}

struct StatusPill: View {
    let bill: Bill

    var label: String {
        if bill.isPaid { return "Paid" }
        if bill.isOverdue { return "Overdue" }
        if bill.isDueSoon { return "Due Soon" }
        return "Upcoming"
    }

    var color: Color {
        if bill.isPaid { return Constants.successColor }
        if bill.isOverdue { return Constants.dangerColor }
        if bill.isDueSoon { return Constants.warningColor }
        return Constants.accentColor
    }

    var body: some View {
        Text(label)
            .font(.caption.weight(.semibold))
            .padding(.horizontal, 12)
            .padding(.vertical, 5)
            .background(color.opacity(0.15), in: Capsule())
            .foregroundStyle(color)
    }
}

struct DetailRow: View {
    let label: String
    let value: String

    var body: some View {
        HStack {
            Text(label)
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Spacer()
            Text(value)
                .font(.subheadline.weight(.medium))
                .multilineTextAlignment(.trailing)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 14)
    }
}
