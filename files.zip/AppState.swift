// AppState.swift
// Global observable state shared across the app via @EnvironmentObject

import SwiftUI
import Combine

final class AppState: ObservableObject {
    @Published var selectedTab: Tab = .dashboard
    @Published var showAddBill: Bool = false
    @Published var showAddSubscription: Bool = false
    @Published var errorMessage: String? = nil
    @Published var successMessage: String? = nil

    enum Tab: Int, CaseIterable {
        case dashboard = 0
        case bills = 1
        case subscriptions = 2
        case analytics = 3
    }

    func showError(_ message: String) {
        DispatchQueue.main.async {
            self.errorMessage = message
        }
    }

    func showSuccess(_ message: String) {
        DispatchQueue.main.async {
            self.successMessage = message
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                self.successMessage = nil
            }
        }
    }
}
