// MainTabView.swift
// Root tab navigation with injected ViewModels

import SwiftUI

struct MainTabView: View {
    @EnvironmentObject var authVM: AuthViewModel
    @EnvironmentObject var appState: AppState

    @StateObject private var billVM = BillViewModel()
    @StateObject private var subVM  = SubscriptionViewModel()
    @StateObject private var analyticsVM = AnalyticsViewModel()
    @StateObject private var dashVM = DashboardViewModel()

    var body: some View {
        TabView(selection: $appState.selectedTab) {
            DashboardView()
                .tabItem { Label("Dashboard", systemImage: "square.grid.2x2.fill") }
                .tag(AppState.Tab.dashboard)

            BillListView()
                .tabItem { Label("Bills", systemImage: "doc.text.fill") }
                .tag(AppState.Tab.bills)

            SubscriptionListView()
                .tabItem { Label("Subscriptions", systemImage: "arrow.triangle.2.circlepath") }
                .tag(AppState.Tab.subscriptions)

            AnalyticsView()
                .tabItem { Label("Analytics", systemImage: "chart.bar.fill") }
                .tag(AppState.Tab.analytics)
        }
        .tint(Constants.accentColor)
        .environmentObject(billVM)
        .environmentObject(subVM)
        .environmentObject(analyticsVM)
        .environmentObject(dashVM)
        .onAppear {
            let uid = authVM.uid
            billVM.startListening(uid: uid)
            subVM.startListening(uid: uid)
            dashVM.setup(name: authVM.user?.displayName ?? "")

            Task {
                _ = await NotificationService.shared.requestAuthorization()
            }
        }
        .onDisappear {
            billVM.stopListening()
            subVM.stopListening()
        }
        .overlay(alignment: .top) {
            if let success = appState.successMessage {
                ToastView(message: success, isSuccess: true)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .animation(Constants.Animation.spring, value: appState.successMessage)
                    .zIndex(999)
                    .padding(.top, 50)
            }
        }
    }
}

// MARK: - Toast
struct ToastView: View {
    let message: String
    let isSuccess: Bool

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: isSuccess ? "checkmark.circle.fill" : "exclamationmark.circle.fill")
                .foregroundStyle(isSuccess ? Constants.successColor : Constants.dangerColor)
            Text(message)
                .font(.subheadline.weight(.medium))
                .foregroundStyle(.primary)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(.ultraThinMaterial, in: Capsule())
        .shadow(color: .black.opacity(0.1), radius: 8)
    }
}

// MARK: - LoadingView
struct LoadingView: View {
    var body: some View {
        VStack(spacing: 16) {
            ProgressView()
                .scaleEffect(1.4)
                .tint(Constants.accentColor)
            Text("Loading BillWise…")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.systemBackground))
    }
}

// MARK: - SectionHeader
struct SectionHeader: View {
    let title: String
    var actionLabel: String? = nil
    var action: (() -> Void)? = nil

    var body: some View {
        HStack {
            Text(title)
                .font(.title3.weight(.semibold))
            Spacer()
            if let label = actionLabel, let action = action {
                Button(label, action: action)
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(Constants.accentColor)
            }
        }
    }
}

// MARK: - EmptyStateView
struct EmptyStateView: View {
    let icon: String
    let title: String
    let subtitle: String

    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 48))
                .foregroundStyle(Constants.accentColor.opacity(0.6))
            Text(title)
                .font(.headline)
            Text(subtitle)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(32)
    }
}

// MARK: - AmountBadge
struct AmountBadge: View {
    let amount: Double
    let color: Color

    var body: some View {
        Text(amount.currencyFormatted())
            .font(.subheadline.weight(.bold))
            .foregroundStyle(color)
            .padding(.horizontal, 10)
            .padding(.vertical, 4)
            .background(color.opacity(0.12), in: Capsule())
    }
}
