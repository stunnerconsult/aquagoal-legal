// BillWiseApp.swift
// App entry point — configures Firebase and injects environment objects

import SwiftUI
import Firebase

@main
struct BillWiseApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var authVM = AuthViewModel()

    init() {
        FirebaseApp.configure()
    }

    var body: some Scene {
        WindowGroup {
            ContentRootView()
                .environmentObject(appState)
                .environmentObject(authVM)
        }
    }
}

// MARK: - ContentRootView
struct ContentRootView: View {
    @EnvironmentObject var authVM: AuthViewModel

    var body: some View {
        Group {
            if authVM.isLoading {
                LoadingView()
            } else if authVM.user != nil {
                MainTabView()
            } else {
                LoginView()
            }
        }
        .animation(.easeInOut(duration: 0.3), value: authVM.user?.uid)
    }
}
