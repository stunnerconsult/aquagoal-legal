// SubscriptionViewModel.swift

import SwiftUI
import Combine

@MainActor
final class SubscriptionViewModel: ObservableObject {
    @Published var subscriptions: [Subscription] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    private var cancellables = Set<AnyCancellable>()
    private let firestore = FirestoreService.shared
    private let notifications = NotificationService.shared

    var activeSubscriptions: [Subscription] {
        subscriptions.filter { $0.isActive }
    }

    var totalMonthlySpend: Double {
        activeSubscriptions.reduce(0) { $0 + $1.monthlyEquivalent }
    }

    var totalYearlySpend: Double { totalMonthlySpend * 12 }

    var upcomingRenewals: [Subscription] {
        activeSubscriptions
            .filter {
                let days = Calendar.current.dateComponents([.day], from: Date(), to: $0.nextBillingDate).day ?? 0
                return days >= 0 && days <= 7
            }
            .sorted { $0.nextBillingDate < $1.nextBillingDate }
    }

    var byCategory: [BillCategory: [Subscription]] {
        Dictionary(grouping: activeSubscriptions, by: { $0.category })
    }

    func startListening(uid: String) {
        isLoading = true
        firestore.subscriptionsPublisher(uid: uid)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                self?.isLoading = false
                if case .failure(let error) = completion {
                    self?.errorMessage = error.localizedDescription
                }
            } receiveValue: { [weak self] subs in
                self?.subscriptions = subs
                self?.isLoading = false
                subs.filter { $0.isActive }.forEach {
                    self?.notifications.scheduleSubscriptionReminder(for: $0)
                }
            }
            .store(in: &cancellables)
    }

    func stopListening() {
        cancellables.removeAll()
    }

    func addSubscription(_ sub: Subscription, uid: String) async {
        do {
            let id = try await firestore.addSubscription(sub, uid: uid)
            var scheduled = sub
            scheduled.id = id
            if sub.isActive { notifications.scheduleSubscriptionReminder(for: scheduled) }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func updateSubscription(_ sub: Subscription, uid: String) async {
        do {
            try await firestore.updateSubscription(sub, uid: uid)
            if let id = sub.id { notifications.cancelSubscriptionReminder(id: id) }
            if sub.isActive { notifications.scheduleSubscriptionReminder(for: sub) }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func deleteSubscription(_ sub: Subscription, uid: String) async {
        guard let id = sub.id else { return }
        do {
            try await firestore.deleteSubscription(id: id, uid: uid)
            notifications.cancelSubscriptionReminder(id: id)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func toggleActive(_ sub: Subscription, uid: String) async {
        var updated = sub
        updated.isActive = !sub.isActive
        await updateSubscription(updated, uid: uid)
    }
}
