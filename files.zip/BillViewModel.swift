// BillViewModel.swift

import SwiftUI
import Combine

@MainActor
final class BillViewModel: ObservableObject {
    @Published var bills: [Bill] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    private var cancellables = Set<AnyCancellable>()
    private let firestore = FirestoreService.shared
    private let notifications = NotificationService.shared

    var upcomingBills: [Bill] {
        bills
            .filter { !$0.isPaid && $0.dueDate >= Date() }
            .sorted { $0.dueDate < $1.dueDate }
    }

    var overdueBills: [Bill] {
        bills.filter { $0.isOverdue }.sorted { $0.dueDate < $1.dueDate }
    }

    var paidBills: [Bill] {
        bills.filter { $0.isPaid }.sorted { $0.dueDate > $1.dueDate }
    }

    var totalUpcoming: Double {
        upcomingBills.reduce(0) { $0 + $1.amount }
    }

    var totalOverdue: Double {
        overdueBills.reduce(0) { $0 + $1.amount }
    }

    func startListening(uid: String) {
        isLoading = true
        firestore.billsPublisher(uid: uid)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                self?.isLoading = false
                if case .failure(let error) = completion {
                    self?.errorMessage = error.localizedDescription
                }
            } receiveValue: { [weak self] bills in
                self?.bills = bills
                self?.isLoading = false
                // Reschedule notifications whenever bills update
                bills.forEach { self?.notifications.scheduleBillReminder(for: $0) }
            }
            .store(in: &cancellables)
    }

    func stopListening() {
        cancellables.removeAll()
    }

    func addBill(_ bill: Bill, uid: String) async {
        do {
            let id = try await firestore.addBill(bill, uid: uid)
            var scheduled = bill
            scheduled.id = id
            notifications.scheduleBillReminder(for: scheduled)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func updateBill(_ bill: Bill, uid: String) async {
        do {
            try await firestore.updateBill(bill, uid: uid)
            notifications.scheduleBillReminder(for: bill)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func deleteBill(_ bill: Bill, uid: String) async {
        guard let id = bill.id else { return }
        do {
            try await firestore.deleteBill(id: id, uid: uid)
            notifications.cancelBillReminder(id: id)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func togglePaid(_ bill: Bill, uid: String) async {
        guard let id = bill.id else { return }
        do {
            try await firestore.markBillPaid(id: id, uid: uid, paid: !bill.isPaid)
            if !bill.isPaid {
                // Was unpaid, now marking paid — record payment
                let payment = PaymentRecord(
                    billId: id,
                    subscriptionId: nil,
                    amount: bill.amount,
                    paidAt: Date(),
                    note: "Marked paid"
                )
                try await firestore.addPayment(payment, uid: uid)
                notifications.cancelBillReminder(id: id)
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
