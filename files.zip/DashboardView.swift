// DashboardView.swift
// Main home screen with summary cards, upcoming bills, and quick actions

import SwiftUI

struct DashboardView: View {
    @EnvironmentObject var authVM: AuthViewModel
    @EnvironmentObject var appState: AppState
    @EnvironmentObject var billVM: BillViewModel
    @EnvironmentObject var subVM: SubscriptionViewModel
    @EnvironmentObject var dashVM: DashboardViewModel

    @State private var showAddBill = false
    @State private var showAddSub = false
    @State private var showProfile = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // Greeting Header
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(dashVM.greeting + ",")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                            Text(dashVM.userName.isEmpty ? "Friend" : dashVM.userName)
                                .font(.title.bold())
                        }
                        Spacer()
                        Button {
                            showProfile = true
                        } label: {
                            Circle()
                                .fill(Constants.accentColor.gradient)
                                .frame(width: 42, height: 42)
                                .overlay {
                                    Text(String(dashVM.userName.prefix(1)).uppercased())
                                        .font(.headline.bold())
                                        .foregroundStyle(.white)
                                }
                        }
                    }
                    .padding(.horizontal, Constants.Padding.screen)

                    // Summary Cards
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            SummaryCard(
                                title: "Monthly Bills",
                                amount: billVM.totalUpcoming,
                                icon: "doc.text.fill",
                                color: Constants.accentColor,
                                subtitle: "\(billVM.upcomingBills.count) upcoming"
                            )
                            SummaryCard(
                                title: "Subscriptions",
                                amount: subVM.totalMonthlySpend,
                                icon: "arrow.triangle.2.circlepath",
                                color: .purple,
                                subtitle: "\(subVM.activeSubscriptions.count) active"
                            )
                            SummaryCard(
                                title: "Overdue",
                                amount: billVM.totalOverdue,
                                icon: "exclamationmark.circle.fill",
                                color: Constants.dangerColor,
                                subtitle: "\(billVM.overdueBills.count) bills"
                            )
                        }
                        .padding(.horizontal, Constants.Padding.screen)
                    }

                    // Total Monthly Spend hero
                    TotalSpendCard(
                        billsTotal: billVM.totalUpcoming,
                        subsTotal: subVM.totalMonthlySpend
                    )
                    .padding(.horizontal, Constants.Padding.screen)

                    // Overdue Section
                    if !billVM.overdueBills.isEmpty {
                        VStack(spacing: 12) {
                            SectionHeader(title: "⚠️ Overdue")
                                .padding(.horizontal, Constants.Padding.screen)

                            ForEach(billVM.overdueBills.prefix(3)) { bill in
                                NavigationLink(destination: BillDetailView(bill: bill)) {
                                    BillRowView(bill: bill)
                                }
                                .padding(.horizontal, Constants.Padding.screen)
                            }
                        }
                    }

                    // Upcoming Bills
                    VStack(spacing: 12) {
                        SectionHeader(
                            title: "Upcoming Bills",
                            actionLabel: "See All"
                        ) { appState.selectedTab = .bills }
                            .padding(.horizontal, Constants.Padding.screen)

                        if billVM.upcomingBills.isEmpty {
                            EmptyStateView(icon: "checkmark.circle.fill", title: "All clear!", subtitle: "No upcoming bills")
                        } else {
                            ForEach(billVM.upcomingBills.prefix(4)) { bill in
                                NavigationLink(destination: BillDetailView(bill: bill)) {
                                    BillRowView(bill: bill)
                                }
                                .padding(.horizontal, Constants.Padding.screen)
                            }
                        }
                    }

                    // Upcoming Subscription Renewals
                    if !subVM.upcomingRenewals.isEmpty {
                        VStack(spacing: 12) {
                            SectionHeader(
                                title: "Renewing Soon",
                                actionLabel: "See All"
                            ) { appState.selectedTab = .subscriptions }
                                .padding(.horizontal, Constants.Padding.screen)

                            ForEach(subVM.upcomingRenewals.prefix(3)) { sub in
                                NavigationLink(destination: SubscriptionDetailView(subscription: sub)) {
                                    SubscriptionRowView(subscription: sub)
                                }
                                .padding(.horizontal, Constants.Padding.screen)
                            }
                        }
                    }

                    Spacer(minLength: 100)
                }
                .padding(.top, 16)
            }
            .navigationBarHidden(true)
            .overlay(alignment: .bottomTrailing) {
                QuickAddMenu(showAddBill: $showAddBill, showAddSub: $showAddSub)
                    .padding(24)
            }
            .sheet(isPresented: $showAddBill) {
                AddEditBillView(mode: .add)
            }
            .sheet(isPresented: $showAddSub) {
                AddEditSubscriptionView(mode: .add)
            }
            .sheet(isPresented: $showProfile) {
                ProfileView()
            }
        }
    }
}

// MARK: - SummaryCard
struct SummaryCard: View {
    let title: String
    let amount: Double
    let icon: String
    let color: Color
    let subtitle: String

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: icon)
                    .foregroundStyle(color)
                    .font(.system(size: 18, weight: .semibold))
                Spacer()
            }

            Text(amount.currencyFormatted())
                .font(.system(size: 22, weight: .bold, design: .rounded))
                .minimumScaleFactor(0.7)

            Text(title)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
                .textCase(.uppercase)
                .tracking(0.5)

            Text(subtitle)
                .font(.caption)
                .foregroundStyle(color)
                .padding(.horizontal, 8)
                .padding(.vertical, 3)
                .background(color.opacity(0.12), in: Capsule())
        }
        .padding(16)
        .frame(width: 160)
        .shadowCard()
    }
}

// MARK: - TotalSpendCard
struct TotalSpendCard: View {
    let billsTotal: Double
    let subsTotal: Double

    var total: Double { billsTotal + subsTotal }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("TOTAL THIS MONTH")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.white.opacity(0.7))
                        .tracking(0.8)
                    Text(total.currencyFormatted())
                        .font(.system(size: 34, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                }
                Spacer()
                Image(systemName: "chart.pie.fill")
                    .font(.system(size: 32))
                    .foregroundStyle(.white.opacity(0.4))
            }

            Divider().background(.white.opacity(0.2))

            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Bills")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.7))
                    Text(billsTotal.currencyFormatted())
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 2) {
                    Text("Subscriptions")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.7))
                    Text(subsTotal.currencyFormatted())
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white)
                }
            }
        }
        .padding(20)
        .background(Constants.accentColor.gradient, in: RoundedRectangle(cornerRadius: 20))
        .shadow(color: Constants.accentColor.opacity(0.4), radius: 12, y: 6)
    }
}

// MARK: - QuickAddMenu
struct QuickAddMenu: View {
    @Binding var showAddBill: Bool
    @Binding var showAddSub: Bool
    @State private var expanded = false

    var body: some View {
        VStack(alignment: .trailing, spacing: 12) {
            if expanded {
                QuickActionButton(label: "Add Subscription", icon: "arrow.triangle.2.circlepath", color: .purple) {
                    expanded = false
                    showAddSub = true
                }
                QuickActionButton(label: "Add Bill", icon: "doc.text.fill", color: Constants.accentColor) {
                    expanded = false
                    showAddBill = true
                }
            }

            Button {
                withAnimation(Constants.Animation.spring) { expanded.toggle() }
            } label: {
                Image(systemName: expanded ? "xmark" : "plus")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 56, height: 56)
                    .background(Constants.accentColor, in: Circle())
                    .shadow(color: Constants.accentColor.opacity(0.4), radius: 8, y: 4)
                    .rotationEffect(.degrees(expanded ? 0 : 0))
            }
        }
    }
}

struct QuickActionButton: View {
    let label: String
    let icon: String
    let color: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 10) {
                Text(label)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.primary)
                Image(systemName: icon)
                    .foregroundStyle(color)
                    .frame(width: 36, height: 36)
                    .background(color.opacity(0.15), in: Circle())
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .shadowCard()
        }
    }
}

// MARK: - ProfileView
struct ProfileView: View {
    @EnvironmentObject var authVM: AuthViewModel
    @Environment(\.dismiss) var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section {
                    HStack(spacing: 16) {
                        Circle()
                            .fill(Constants.accentColor.gradient)
                            .frame(width: 60, height: 60)
                            .overlay {
                                Text(String((authVM.user?.displayName ?? "?").prefix(1)).uppercased())
                                    .font(.title2.bold())
                                    .foregroundStyle(.white)
                            }
                        VStack(alignment: .leading, spacing: 4) {
                            Text(authVM.user?.displayName ?? "")
                                .font(.headline)
                            Text(authVM.user?.email ?? "")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 8)
                }

                Section("Account") {
                    Button(role: .destructive) {
                        authVM.signOut()
                        dismiss()
                    } label: {
                        Label("Sign Out", systemImage: "rectangle.portrait.and.arrow.right")
                    }
                }
            }
            .navigationTitle("Profile")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}
