// SubscriptionListView.swift

import SwiftUI

struct SubscriptionListView: View {
    @EnvironmentObject var subVM: SubscriptionViewModel
    @EnvironmentObject var authVM: AuthViewModel
    @State private var showAdd = false
    @State private var showInactive = false

    var displayedSubs: [Subscription] {
        showInactive ? subVM.subscriptions : subVM.activeSubscriptions
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // Monthly total header card
                    MonthlySubCard(
                        monthly: subVM.totalMonthlySpend,
                        yearly: subVM.totalYearlySpend,
                        count: subVM.activeSubscriptions.count
                    )
                    .padding(.horizontal, Constants.Padding.screen)

                    // Toggle inactive
                    Toggle("Show inactive", isOn: $showInactive)
                        .font(.subheadline)
                        .padding(.horizontal, Constants.Padding.screen)

                    if subVM.isLoading {
                        ProgressView()
                    } else if displayedSubs.isEmpty {
                        EmptyStateView(
                            icon: "arrow.triangle.2.circlepath",
                            title: "No Subscriptions",
                            subtitle: "Track your recurring subscriptions"
                        )
                    } else {
                        VStack(spacing: 10) {
                            ForEach(displayedSubs) { sub in
                                NavigationLink(destination: SubscriptionDetailView(subscription: sub)) {
                                    SubscriptionRowView(subscription: sub)
                                }
                                .padding(.horizontal, Constants.Padding.screen)
                            }
                        }
                    }

                    Spacer(minLength: 100)
                }
                .padding(.top, 16)
            }
            .navigationTitle("Subscriptions")
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button { showAdd = true } label: {
                        Image(systemName: "plus.circle.fill")
                            .font(.title2)
                            .foregroundStyle(Constants.accentColor)
                    }
                }
            }
            .sheet(isPresented: $showAdd) {
                AddEditSubscriptionView(mode: .add)
            }
        }
    }
}

// MARK: - MonthlySubCard
struct MonthlySubCard: View {
    let monthly: Double
    let yearly: Double
    let count: Int

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("\(count) active subscription\(count == 1 ? "" : "s")")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(monthly.currencyFormatted() + "/mo")
                    .font(.title2.bold())
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 4) {
                Text("Per year")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(yearly.currencyFormatted())
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(Constants.accentColor)
            }
        }
        .padding(16)
        .shadowCard()
    }
}

// MARK: - SubscriptionRowView
struct SubscriptionRowView: View {
    let subscription: Subscription

    var daysUntilRenewal: Int {
        Calendar.current.dateComponents([.day], from: Date(), to: subscription.nextBillingDate).day ?? 0
    }

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color(hex: subscription.colorHex).opacity(0.15))
                    .frame(width: 48, height: 48)
                Image(systemName: subscription.icon)
                    .font(.system(size: 22, weight: .medium))
                    .foregroundStyle(Color(hex: subscription.colorHex))
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(subscription.name)
                    .font(.subheadline.weight(.semibold))
                Text(subscription.category.rawValue)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 4) {
                Text(subscription.amount.currencyFormatted())
                    .font(.subheadline.weight(.bold))
                Text(subscription.billingCycle.shortLabel)
                    .font(.caption)
                    .foregroundStyle(.secondary)

                if !subscription.isActive {
                    Text("Paused")
                        .font(.caption2.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(.secondary.opacity(0.15), in: Capsule())
                } else if daysUntilRenewal <= 7 {
                    Text("Due in \(daysUntilRenewal)d")
                        .font(.caption2.weight(.semibold))
                        .foregroundStyle(Constants.warningColor)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Constants.warningColor.opacity(0.12), in: Capsule())
                }
            }
        }
        .padding(Constants.Padding.card)
        .shadowCard()
        .opacity(subscription.isActive ? 1.0 : 0.6)
    }
}

// MARK: - SubscriptionDetailView
struct SubscriptionDetailView: View {
    @EnvironmentObject var subVM: SubscriptionViewModel
    @EnvironmentObject var authVM: AuthViewModel
    @Environment(\.dismiss) var dismiss

    let subscription: Subscription
    @State private var showEdit = false
    @State private var showDeleteAlert = false

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Hero
                VStack(spacing: 12) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color(hex: subscription.colorHex).gradient)
                            .frame(width: 90, height: 90)
                        Image(systemName: subscription.icon)
                            .font(.system(size: 40))
                            .foregroundStyle(.white)
                    }
                    Text(subscription.name)
                        .font(.title2.bold())
                    Text(subscription.amount.currencyFormatted() + subscription.billingCycle.shortLabel)
                        .font(.system(size: 32, weight: .bold, design: .rounded))
                        .foregroundStyle(Color(hex: subscription.colorHex))
                    Text("~\(subscription.monthlyEquivalent.currencyFormatted())/month")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .padding(.top, 20)

                // Details
                VStack(spacing: 0) {
                    DetailRow(label: "Provider", value: subscription.provider.isEmpty ? "—" : subscription.provider)
                    Divider().padding(.leading, 16)
                    DetailRow(label: "Category", value: subscription.category.rawValue)
                    Divider().padding(.leading, 16)
                    DetailRow(label: "Billing Cycle", value: subscription.billingCycle.displayName)
                    Divider().padding(.leading, 16)
                    DetailRow(label: "Next Billing", value: subscription.nextBillingDate.relativeLabel)
                    Divider().padding(.leading, 16)
                    DetailRow(label: "Reminder", value: "\(subscription.reminderDays) day(s) before")
                    Divider().padding(.leading, 16)
                    DetailRow(label: "Status", value: subscription.isActive ? "Active" : "Paused")
                }
                .shadowCard()
                .padding(.horizontal, Constants.Padding.screen)

                // Actions
                VStack(spacing: 12) {
                    Button {
                        Task {
                            await subVM.toggleActive(subscription, uid: authVM.uid)
                            dismiss()
                        }
                    } label: {
                        Label(subscription.isActive ? "Pause Subscription" : "Resume Subscription",
                              systemImage: subscription.isActive ? "pause.circle" : "play.circle.fill")
                            .font(.headline)
                            .frame(maxWidth: .infinity).frame(height: 52)
                            .background(Color.secondary.opacity(0.15), in: RoundedRectangle(cornerRadius: 14))
                            .foregroundStyle(.primary)
                    }

                    Button(role: .destructive) { showDeleteAlert = true } label: {
                        Label("Delete Subscription", systemImage: "trash")
                            .font(.headline)
                            .frame(maxWidth: .infinity).frame(height: 52)
                            .background(Constants.dangerColor.opacity(0.1), in: RoundedRectangle(cornerRadius: 14))
                            .foregroundStyle(Constants.dangerColor)
                    }
                }
                .padding(.horizontal, Constants.Padding.screen)
            }
        }
        .navigationTitle(subscription.category.rawValue)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button("Edit") { showEdit = true }.foregroundStyle(Constants.accentColor)
            }
        }
        .sheet(isPresented: $showEdit) { AddEditSubscriptionView(mode: .edit(subscription)) }
        .alert("Delete Subscription?", isPresented: $showDeleteAlert) {
            Button("Delete", role: .destructive) {
                Task { await subVM.deleteSubscription(subscription, uid: authVM.uid); dismiss() }
            }
            Button("Cancel", role: .cancel) {}
        }
    }
}

// MARK: - AddEditSubscriptionView
struct AddEditSubscriptionView: View {
    @EnvironmentObject var subVM: SubscriptionViewModel
    @EnvironmentObject var authVM: AuthViewModel
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) var dismiss

    let mode: FormMode<Subscription>

    @State private var name = ""
    @State private var amount = ""
    @State private var billingCycle: BillingCycle = .monthly
    @State private var nextBillingDate = Date()
    @State private var category: BillCategory = .entertainment
    @State private var provider = ""
    @State private var colorHex = "#4F6EF7"
    @State private var icon = "play.rectangle.fill"
    @State private var reminderDays = 2
    @State private var isSaving = false

    var isEditing: Bool { if case .edit = mode { return true }; return false }
    var originalSub: Subscription? { if case .edit(let s) = mode { return s }; return nil }
    var isValid: Bool { !name.isEmpty && Double(amount) != nil }

    let iconOptions = ["play.rectangle.fill", "tv.fill", "music.note", "gamecontroller.fill",
                       "cloud.fill", "newspaper.fill", "heart.fill", "cart.fill",
                       "book.fill", "camera.fill", "mic.fill", "wifi"]

    var body: some View {
        NavigationStack {
            Form {
                Section("Subscription Info") {
                    TextField("Name (e.g. Netflix)", text: $name)
                    HStack {
                        Text("$")
                        TextField("Amount", text: $amount).keyboardType(.decimalPad)
                    }
                    TextField("Provider (optional)", text: $provider)
                }

                Section("Billing") {
                    Picker("Billing Cycle", selection: $billingCycle) {
                        ForEach(BillingCycle.allCases, id: \.self) {
                            Text($0.displayName).tag($0)
                        }
                    }
                    DatePicker("Next Billing Date", selection: $nextBillingDate, displayedComponents: .date)
                    Picker("Category", selection: $category) {
                        ForEach(BillCategory.allCases, id: \.self) {
                            Label($0.rawValue, systemImage: $0.icon).tag($0)
                        }
                    }
                }

                Section("Appearance") {
                    ColorPicker("Color", selection: Binding(
                        get: { Color(hex: colorHex) },
                        set: { colorHex = UIColor($0).hex }
                    ))

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            ForEach(iconOptions, id: \.self) { sym in
                                ZStack {
                                    RoundedRectangle(cornerRadius: 10)
                                        .fill(icon == sym ? Color(hex: colorHex) : Color(.secondarySystemBackground))
                                        .frame(width: 44, height: 44)
                                    Image(systemName: sym)
                                        .foregroundStyle(icon == sym ? .white : .secondary)
                                }
                                .onTapGesture { icon = sym }
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }

                Section("Reminder") {
                    Stepper("Remind \(reminderDays) day(s) before", value: $reminderDays, in: 1...14)
                }
            }
            .navigationTitle(isEditing ? "Edit Subscription" : "New Subscription")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button(isSaving ? "Saving…" : "Save") { Task { await save() } }
                        .disabled(!isValid || isSaving).fontWeight(.semibold)
                }
            }
            .onAppear { populateIfEditing() }
        }
    }

    private func populateIfEditing() {
        guard let s = originalSub else { return }
        name = s.name; amount = String(s.amount); billingCycle = s.billingCycle
        nextBillingDate = s.nextBillingDate; category = s.category; provider = s.provider
        colorHex = s.colorHex; icon = s.icon; reminderDays = s.reminderDays
    }

    private func save() async {
        isSaving = true
        let sub = Subscription(
            id: originalSub?.id, name: name,
            amount: Double(amount) ?? 0, billingCycle: billingCycle,
            nextBillingDate: nextBillingDate, category: category,
            provider: provider, isActive: originalSub?.isActive ?? true,
            colorHex: colorHex, icon: icon,
            reminderDays: reminderDays, createdAt: originalSub?.createdAt ?? Date()
        )
        if isEditing { await subVM.updateSubscription(sub, uid: authVM.uid) }
        else { await subVM.addSubscription(sub, uid: authVM.uid) }
        appState.showSuccess(isEditing ? "Subscription updated!" : "Subscription added!")
        isSaving = false
        dismiss()
    }
}

// UIColor extension for hex conversion
extension UIColor {
    var hex: String {
        var r: CGFloat = 0; var g: CGFloat = 0; var b: CGFloat = 0; var a: CGFloat = 0
        getRed(&r, green: &g, blue: &b, alpha: &a)
        return String(format: "#%02X%02X%02X", Int(r*255), Int(g*255), Int(b*255))
    }
}
