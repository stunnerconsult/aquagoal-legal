// FirestoreService.swift
// Centralized Firestore data access layer

import Foundation
import FirebaseFirestore
import FirebaseFirestoreSwift
import Combine

final class FirestoreService {
    static let shared = FirestoreService()
    private let db = Firestore.firestore()

    private init() {}

    // MARK: - Collection References

    private func userRef(_ uid: String) -> DocumentReference {
        db.collection("users").document(uid)
    }

    private func billsRef(_ uid: String) -> CollectionReference {
        userRef(uid).collection("bills")
    }

    private func subscriptionsRef(_ uid: String) -> CollectionReference {
        userRef(uid).collection("subscriptions")
    }

    private func paymentsRef(_ uid: String) -> CollectionReference {
        userRef(uid).collection("payments")
    }

    // MARK: - User

    func createUser(_ user: BillWiseUser, uid: String) async throws {
        try userRef(uid).setData(from: user)
    }

    func fetchUser(uid: String) async throws -> BillWiseUser? {
        let snapshot = try await userRef(uid).getDocument()
        return try snapshot.data(as: BillWiseUser.self)
    }

    func updateUser(_ user: BillWiseUser, uid: String) async throws {
        try userRef(uid).setData(from: user, merge: true)
    }

    // MARK: - Bills: Real-time listener

    func billsPublisher(uid: String) -> AnyPublisher<[Bill], Error> {
        let subject = PassthroughSubject<[Bill], Error>()

        let listener = billsRef(uid)
            .order(by: "dueDate", descending: false)
            .addSnapshotListener { snapshot, error in
                if let error = error {
                    subject.send(completion: .failure(error))
                    return
                }
                let bills = snapshot?.documents.compactMap { doc -> Bill? in
                    try? doc.data(as: Bill.self)
                } ?? []
                subject.send(bills)
            }

        return subject
            .handleEvents(receiveCancel: { listener.remove() })
            .eraseToAnyPublisher()
    }

    func addBill(_ bill: Bill, uid: String) async throws -> String {
        let ref = try billsRef(uid).addDocument(from: bill)
        return ref.documentID
    }

    func updateBill(_ bill: Bill, uid: String) async throws {
        guard let id = bill.id else { throw AppError.missingID }
        try billsRef(uid).document(id).setData(from: bill, merge: true)
    }

    func deleteBill(id: String, uid: String) async throws {
        try await billsRef(uid).document(id).delete()
    }

    func markBillPaid(id: String, uid: String, paid: Bool) async throws {
        try await billsRef(uid).document(id).updateData(["isPaid": paid])
    }

    // MARK: - Subscriptions: Real-time listener

    func subscriptionsPublisher(uid: String) -> AnyPublisher<[Subscription], Error> {
        let subject = PassthroughSubject<[Subscription], Error>()

        let listener = subscriptionsRef(uid)
            .order(by: "nextBillingDate", descending: false)
            .addSnapshotListener { snapshot, error in
                if let error = error {
                    subject.send(completion: .failure(error))
                    return
                }
                let subs = snapshot?.documents.compactMap { doc -> Subscription? in
                    try? doc.data(as: Subscription.self)
                } ?? []
                subject.send(subs)
            }

        return subject
            .handleEvents(receiveCancel: { listener.remove() })
            .eraseToAnyPublisher()
    }

    func addSubscription(_ sub: Subscription, uid: String) async throws -> String {
        let ref = try subscriptionsRef(uid).addDocument(from: sub)
        return ref.documentID
    }

    func updateSubscription(_ sub: Subscription, uid: String) async throws {
        guard let id = sub.id else { throw AppError.missingID }
        try subscriptionsRef(uid).document(id).setData(from: sub, merge: true)
    }

    func deleteSubscription(id: String, uid: String) async throws {
        try await subscriptionsRef(uid).document(id).delete()
    }

    // MARK: - Payments

    func addPayment(_ payment: PaymentRecord, uid: String) async throws {
        _ = try paymentsRef(uid).addDocument(from: payment)
    }

    func fetchPayments(uid: String, from: Date, to: Date) async throws -> [PaymentRecord] {
        let snapshot = try await paymentsRef(uid)
            .whereField("paidAt", isGreaterThanOrEqualTo: from)
            .whereField("paidAt", isLessThanOrEqualTo: to)
            .order(by: "paidAt", descending: true)
            .getDocuments()

        return snapshot.documents.compactMap { try? $0.data(as: PaymentRecord.self) }
    }
}

// MARK: - App Errors
enum AppError: LocalizedError {
    case missingID
    case authFailed(String)
    case firestoreFailed(String)
    case unknown

    var errorDescription: String? {
        switch self {
        case .missingID:               return "Document ID is missing."
        case .authFailed(let msg):     return "Auth error: \(msg)"
        case .firestoreFailed(let m):  return "Database error: \(m)"
        case .unknown:                 return "An unexpected error occurred."
        }
    }
}
