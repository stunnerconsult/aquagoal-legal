// AnalyticsView.swift
// Monthly spending analytics with Charts framework

import SwiftUI
import Charts

struct AnalyticsView: View {
    @EnvironmentObject var analyticsVM: AnalyticsViewModel
    @EnvironmentObject var billVM: BillViewModel
    @EnvironmentObject var subVM: SubscriptionViewModel

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // Period Picker
                    Picker("Period", selection: $analyticsVM.selectedPeriod) {
                        ForEach(AnalyticsViewModel.Period.allCases, id: \.self) { p in
                            Text(p.rawValue).tag(p)
                        }
                    }
                    .pickerStyle(.segmented)
                    .padding(.horizontal, Constants.Padding.screen)

                    // This month vs last month
                    HStack(spacing: 12) {
                        MonthCompareCard(
                            title: "This Month",
                            amount: analyticsVM.totalThisMonth,
                            isHighlighted: true
                        )
                        MonthCompareCard(
                            title: "Last Month",
                            amount: analyticsVM.totalLastMonth,
                            isHighlighted: false
                        )
                    }
                    .padding(.horizontal, Constants.Padding.screen)

                    // Change indicator
                    if analyticsVM.totalLastMonth > 0 {
                        HStack(spacing: 6) {
                            Image(systemName: analyticsVM.isSpendingUp ? "arrow.up.right" : "arrow.down.right")
                            Text("\(String(format: "%.1f", abs(analyticsVM.changePercent)))% \(analyticsVM.isSpendingUp ? "more" : "less") than last month")
                                .font(.subheadline.weight(.medium))
                        }
                        .foregroundStyle(analyticsVM.isSpendingUp ? Constants.dangerColor : Constants.successColor)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .background(
                            (analyticsVM.isSpendingUp ? Constants.dangerColor : Constants.successColor).opacity(0.1),
                            in: Capsule()
                        )
                    }

                    // Bar Chart
                    if !analyticsVM.monthlySpendData.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Monthly Spending")
                                .font(.headline)
                                .padding(.horizontal, Constants.Padding.screen)

                            Chart(analyticsVM.monthlySpendData) { item in
                                BarMark(
                                    x: .value("Month", item.month),
                                    y: .value("Amount", item.amount)
                                )
                                .foregroundStyle(Constants.accentColor.gradient)
                                .cornerRadius(6)
                                .annotation(position: .top) {
                                    if item.amount > 0 {
                                        Text(item.amount.currencyFormatted())
                                            .font(.system(size: 9, weight: .medium))
                                            .foregroundStyle(.secondary)
                                    }
                                }
                            }
                            .chartYAxis {
                                AxisMarks { value in
                                    AxisGridLine()
                                    AxisValueLabel {
                                        if let v = value.as(Double.self) {
                                            Text(v.currencyFormatted())
                                                .font(.caption2)
                                        }
                                    }
                                }
                            }
                            .frame(height: 220)
                            .padding(.horizontal, Constants.Padding.screen)
                        }
                        .shadowCard()
                        .padding(.horizontal, Constants.Padding.screen)
                    }

                    // Category Breakdown
                    if !analyticsVM.categoryBreakdown.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("This Month by Category")
                                .font(.headline)

                            // Donut chart
                            Chart(analyticsVM.categoryBreakdown) { item in
                                SectorMark(
                                    angle: .value("Amount", item.amount),
                                    innerRadius: .ratio(0.6),
                                    angularInset: 2
                                )
                                .foregroundStyle(Color(hex: item.category.color))
                                .cornerRadius(4)
                            }
                            .frame(height: 200)

                            Divider()

                            // Category list
                            ForEach(analyticsVM.categoryBreakdown) { item in
                                HStack {
                                    Circle()
                                        .fill(Color(hex: item.category.color))
                                        .frame(width: 10, height: 10)
                                    Image(systemName: item.category.icon)
                                        .font(.caption)
                                        .foregroundStyle(Color(hex: item.category.color))
                                    Text(item.category.rawValue)
                                        .font(.subheadline)
                                    Spacer()
                                    Text(item.amount.currencyFormatted())
                                        .font(.subheadline.weight(.semibold))
                                    Text(totalPercent(item.amount))
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                        .frame(width: 44, alignment: .trailing)
                                }
                            }
                        }
                        .padding(16)
                        .shadowCard()
                        .padding(.horizontal, Constants.Padding.screen)
                    }

                    // Subscriptions breakdown
                    if !subVM.activeSubscriptions.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Subscription Breakdown")
                                .font(.headline)

                            ForEach(subVM.activeSubscriptions.sorted { $0.monthlyEquivalent > $1.monthlyEquivalent }) { sub in
                                HStack(spacing: 10) {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 8)
                                            .fill(Color(hex: sub.colorHex).opacity(0.15))
                                            .frame(width: 32, height: 32)
                                        Image(systemName: sub.icon)
                                            .font(.system(size: 14))
                                            .foregroundStyle(Color(hex: sub.colorHex))
                                    }
                                    Text(sub.name)
                                        .font(.subheadline)
                                    Spacer()
                                    Text(sub.monthlyEquivalent.currencyFormatted() + "/mo")
                                        .font(.subheadline.weight(.semibold))
                                }

                                // Progress bar
                                if subVM.totalMonthlySpend > 0 {
                                    ProgressView(value: sub.monthlyEquivalent / subVM.totalMonthlySpend)
                                        .tint(Color(hex: sub.colorHex))
                                }
                            }
                        }
                        .padding(16)
                        .shadowCard()
                        .padding(.horizontal, Constants.Padding.screen)
                    }

                    Spacer(minLength: 60)
                }
                .padding(.top, 16)
            }
            .navigationTitle("Analytics")
            .onChange(of: analyticsVM.selectedPeriod) { _, _ in
                analyticsVM.loadAnalytics(uid: "", bills: billVM.bills, subscriptions: subVM.subscriptions)
            }
            .onAppear {
                analyticsVM.loadAnalytics(uid: "", bills: billVM.bills, subscriptions: subVM.subscriptions)
            }
        }
    }

    func totalPercent(_ amount: Double) -> String {
        let total = analyticsVM.categoryBreakdown.reduce(0) { $0 + $1.amount }
        guard total > 0 else { return "" }
        return "\(Int((amount / total) * 100))%"
    }
}

// MARK: - MonthCompareCard
struct MonthCompareCard: View {
    let title: String
    let amount: Double
    let isHighlighted: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.caption.weight(.semibold))
                .foregroundStyle(isHighlighted ? .white.opacity(0.8) : .secondary)
                .textCase(.uppercase)
                .tracking(0.5)
            Text(amount.currencyFormatted())
                .font(.title3.bold())
                .foregroundStyle(isHighlighted ? .white : .primary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(
            isHighlighted
                ? AnyShapeStyle(Constants.accentColor.gradient)
                : AnyShapeStyle(Color(.secondarySystemBackground)),
            in: RoundedRectangle(cornerRadius: 14)
        )
        .shadow(color: isHighlighted ? Constants.accentColor.opacity(0.3) : .clear, radius: 8, y: 4)
    }
}
